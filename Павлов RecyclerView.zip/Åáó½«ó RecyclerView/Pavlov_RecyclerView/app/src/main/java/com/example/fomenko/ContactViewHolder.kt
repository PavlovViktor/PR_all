package com.example.fomenko

import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class ContactViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    private val nameTextView: TextView = itemView.findViewById(R.id.nameTextView)
    private val phoneTextView: TextView = itemView.findViewById(R.id.phoneTextView)
    private val emailTextView: TextView = itemView.findViewById(R.id.emailTextView)
    private val avatarView: View = itemView.findViewById(R.id.avatarView)

    fun bind(contact: Contact) {
        nameTextView.text = contact.name
        phoneTextView.text = contact.phone
        emailTextView.text = contact.email
        avatarView.setBackgroundColor(contact.avatarColor)

        itemView.setOnClickListener {
            Toast.makeText(itemView.context, "Выбран: ${contact.name}", Toast.LENGTH_SHORT).show()
        }
    }
}