package com.example.fomenko

data class Contact(
    val name: String,
    val phone: String,
    val email: String,
    val avatarColor: Int
)
