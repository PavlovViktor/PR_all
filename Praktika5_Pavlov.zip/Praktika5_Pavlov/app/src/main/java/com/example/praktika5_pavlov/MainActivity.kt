package com.example.praktika5_pavlov

import android.R
import android.annotation.SuppressLint
import android.content.Intent
import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.SimpleCursorAdapter
import com.example.praktika5_pavlov.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var bindingActivityMain: ActivityMainBinding
    private var cursor: Cursor? = null

    @SuppressLint("Range")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bindingActivityMain = ActivityMainBinding.inflate(layoutInflater)
        setContentView(bindingActivityMain.root)

        val listNotes = bindingActivityMain.listViewNotesList

        bindingActivityMain.buttonAddNote.setOnClickListener {
            val intent = Intent(this, NotesActivity::class.java)
            startActivity(intent)
            finish()
        }

        val db = DBHelper(this, null)
        cursor = db.getAllNotes()

        val dataList = ArrayList<String>()
        if (cursor!!.moveToFirst()) {
            do {
                val title = cursor!!.getString(cursor!!.getColumnIndex(DBHelper.TITLENOTE_COLUMN))
                val text = cursor!!.getString(cursor!!.getColumnIndex(DBHelper.TEXTNOTE_COLUMN))

                val noteData = "$title\n$text"
                dataList.add(noteData)
            } while (cursor!!.moveToNext())
        }

        cursor!!.close()
        db.close()

        val adapter = ArrayAdapter<String>(this, R.layout.simple_list_item_1, dataList)
        listNotes.adapter = adapter
    }
}