package com.example.cinema_ppp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val listview = findViewById<ListView>(R.id.listview)

        val Cinema_add = arrayOf(
            Text(
                photo = "https://avatars.mds.yandex.net/get-altay/223006/2a0000015b3bb10e59197f2fbaa61cc25a64/XXL",
                new_tovar = 1,
                name = "Юность",
                price = 200,
                pieces = "г. Курск, ул. Карла Маркса, д. 5",
                date = "25.10.1950"
            ),
            Text(
                photo = "http://onmetwork.ru/upload/medialibrary/a19/a1923ab3af0ac44dd659bd89dcba3cd4.jpg",
                new_tovar = 2,
                name = "ГриннФильм",
                price = 1000,
                pieces = "г. Курск, ул. Карла Маркса, 68",
                date = "25.08.2014"
            ),
            Text(
                photo = "https://static.tildacdn.com/tild3264-3163-4032-b733-396064346635/1599142669-21cae49d4.jpg",
                new_tovar = 3,
                name = "Синема 5",
                price = 1200,
                pieces = "г. Курск, ул. Карла Маркса, 0",
                date = "25.04.2019"
            ),
            Text(
                photo = "https://avatars.mds.yandex.net/get-altay/813485/2a0000015e536040026914307066e40c41a7/XXL_height",
                new_tovar = 4,
                name = "Родина",
                price = 150,
                pieces = "г. Курск, ул. Менделеева, 31 подъезд 1",
                date = "25.04.1970"
            ),
            Text(
                photo = "https://tchops.ru/wp-content/uploads/2021/10/p10.jpg",
                new_tovar = 5,
                name = "Кинотеатр 5 звезд",
                price = 300,
                pieces = "г. Курск, ул. Ленина, 30ТП, Пушкинский этаж 3",
                date = "25.11.2000"
            )
        )

        listview.adapter = CinemaAdapter(this, Cinema_add) // Изменено Cinema на CinemaAdapter
    }
}