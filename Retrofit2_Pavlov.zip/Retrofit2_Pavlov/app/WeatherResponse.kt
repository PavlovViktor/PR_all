package com.example.retrofit2_pavlov

data class WeatherResponse()
