class WeatherRepository {

    private val weatherApi = RetrofitInstance.weatherApi

    suspend fun getWeather(city: String): WeatherResponse? {
        return try {
            weatherApi.getWeather(
                city = city,
                apiKey = RetrofitInstance.API_KEY
            )
        } catch (e: Exception) {
            null
        }
    }
}