package com.example.retrofit2_pavlov

import WeatherRepository
import WeatherResponse
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var tvCity: TextView
    private lateinit var tvTemperature: TextView
    private lateinit var tvDescription: TextView
    private lateinit var btnRefresh: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var tvError: TextView

    private val repository = WeatherRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Находим все View элементы
        tvCity = findViewById(R.id.tvCity)
        tvTemperature = findViewById(R.id.tvTemperature)
        tvDescription = findViewById(R.id.tvDescription)
        btnRefresh = findViewById(R.id.btnRefresh)
        progressBar = findViewById(R.id.progressBar)
        tvError = findViewById(R.id.tvError)

        // Загружаем погоду при запуске
        loadWeather("Moscow")

        // Обработчик кнопки обновления
        btnRefresh.setOnClickListener {
            loadWeather("Moscow")
        }
    }

    private fun loadWeather(city: String) {
        // Показываем прогресс-бар
        progressBar.visibility = View.VISIBLE
        tvError.visibility = View.GONE

        // Используем lifecycleScope вместо создания своего CoroutineScope
        lifecycleScope.launch {
            try {
                val weather = withContext(Dispatchers.IO) {
                    repository.getWeather(city)
                }

                // Скрываем прогресс-бар
                progressBar.visibility = View.GONE

                if (weather != null) {
                    // Успешно получили данные
                    showWeather(weather)
                } else {
                    // Произошла ошибка
                    showError("Не удалось загрузить погоду")
                }
            } catch (e: Exception) {
                progressBar.visibility = View.GONE
                showError("Ошибка: ${e.message}")
                Toast.makeText(
                    this@MainActivity,
                    "Ошибка загрузки",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun showWeather(weather: WeatherResponse) {
        tvCity.text = weather.cityName
        tvTemperature.text = "${weather.main.temperature.toInt()}°C"

        if (weather.weather.isNotEmpty()) {
            val description = weather.weather[0].description
            // Делаем первую букву заглавной
            tvDescription.text = description.replaceFirstChar { it.uppercase() }
        }
    }

    private fun showError(message: String) {
        tvError.text = message
        tvError.visibility = View.VISIBLE
    }

    // Убираем метод onDestroy, так как lifecycleScope автоматически управляет корутинами
}